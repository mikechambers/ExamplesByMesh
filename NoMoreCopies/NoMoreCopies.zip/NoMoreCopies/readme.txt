NoMoreCopies

Created by Mike Chambers
http://mesh.typepad.com

NoMoreCopies is a simple applications that removes duplicate entries from character delimited lists.

Tested on OS X 10.3.5

USE AT YOUR OWN RISK