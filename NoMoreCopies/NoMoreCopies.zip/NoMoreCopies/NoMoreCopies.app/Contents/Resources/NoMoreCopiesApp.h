/* NoMoreCopiesApp */

#import <Cocoa/Cocoa.h>

@interface NoMoreCopiesApp : NSObject
{
    IBOutlet id inputField;
    IBOutlet id outputField;
    IBOutlet id separatorCombo;
	IBOutlet id replaceCheck;
	IBOutlet id trimCheck;
	IBOutlet id resultsField;
}

- (IBAction)onRemoveDuplicatesClick:(id)sender;
- (IBAction)onReplaceRNClick:(id)sender;
- (IBAction)onTrimClick:(id)sender;
- (NSMutableArray *) makeUniqueArray: (NSArray *) arr;
- (NSArray *) createInputArray;

@end
